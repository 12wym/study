# C

## C语言本质

```C
int a = 1;
a++;
a = a + 1;//1.读 2.累加 3.写

//基础知识
对于一个int变量a,其地址addra
cpu读内存，将其地址值放在某个寄存器R0中(cpu存储单元)，
ALU(cpu计算单元)进行累加操作R0=R0+1，
再将R0累加后的结果写回addra

生成的.axf,.hex,.bin文件烧写到flash中

FLASH: a++
1. LDR R0,[addra]
2. ADD R0,#1
3. STR R0,[addra]

数据传输指令
|MOV R0, R1  |将寄存器 R1 的值复制到 R0|
|LDR R0, [R1]|从地址 R1 加载数据到 R0|
|STR R0, [R1]|将 R0 的数据存入地址 R1|
|PUSH R0     |将 R0 压入栈|
|POP R0      |从栈弹出数据到 R0|

算数运算指令
|ADD R0, R1, R2|R0 = R1 + R2|
|SUB R0, R1, R2|R0 = R1 - R2|
|MUL R0, R1, R2|R0 = R1 * R2|
|DIV R0, R1, R2|R0 = R1 / R2（部分架构支持）|
|ADC R0, R1, R2|带进位加法|
|SBC R0, R1, R2|带借位减法|

逻辑运算指令
|AND R0, R1, R2|R0 = R1 & R2（按位与）|
|ORR R0, R1, R2|R0 = R1 \| R2（按位或）|
|EOR R0, R1, R2|R0 = R1 ⊕ R2（按位异或）|
|BIC R0, R1, R2|R0 = R1 & (~R2)（按位清除）|
|MVN R0, R1|R0 = ~R1（按位取反）|

移位与旋转指令
|LSL R0, R1, #2|R0 = R1 << 2（逻辑左移 2 位）|
|LSR R0, R1, #2|R0 = R1 >> 2（逻辑右移 2 位）|
|ASR R0, R1, #2|R0 = R1 算术右移 2 位|
|ROR R0, R1, #2|R0 = R1 循环右移 2 位|

控制转移指令
|B label   |无条件跳转到 `label`|
|BL label  |调用子程序，跳转到 `label` 并保存返回地址|
|BX LR     |返回到调用函数处（常用于子程序返回）|
|CMP R0, R1|比较 R0 和 R1|
|BEQ label |如果相等，则跳转到 `label`|
|BNE label |如果不相等，则跳转到 `label`|
|BGT label |如果大于，则跳转到 `label`|
|BLT label |如果小于，则跳转到 `label`|

栈操作指令
|PUSH {R0, R1}     |将 R0 和 R1 压入栈|
|POP {R0, R1}      |从栈中弹出数据到 R0 和 R1|
|STMFD SP!, {R0-R3}|递减堆栈指针并存储 R0-R3（入栈）|
|LDMFD SP!, {R0-R3}|从栈中恢复 R0-R3 并递增堆栈指针（出栈）|

Code：即代码域，它通常是指编译器生成的机器指令，这些内容会被存储到ROM区。

RO-data：Read Only data，即只读数据域，它指程序中用到的只读数据，这些数据被存储在ROM区，因而程序不能被修改的内容。例如C语言中const关键字定义的变量就是典型的RO-data。

RW-data：Read Write data，即可读写数据域，它指初始化为“非0值”的可读写数据，程序刚运行时，这些数据具有非0的初始值，程序运行的时候它们又会常驻在RAM区，应用程序可以修改其内容。例如C语言中定义的全局变量，且定义时赋予“非0值”给该变量。

ZI-data：Zero Initialie data，即0初始化数据，它指初始化为“0值”的可读写数据域，它与RW-data的区别是程序刚运行时这些数据初始值全都为0，程序运行时和RW-data的性质一样，它们也常驻在RAM区，应用程序可以更改其内容。例如C语言中使用定义的全局变量，且定义时赋予“0值”给该变量(如若定义该变量时没有赋予初始值，编译器会把它当ZI-data来对待，初始化为0)；

R0,...,R11 普通寄存器
R12
R13 SP 栈
R14 LR 返回地址
R15 PC 程序计数器 跳转执行
地址越低，Rx寄存器后面的数字越小

BL指令 Branch And Link 跳转执行，但执行前先记录返回地址
LR = addrb
PC = main地址
```
![](./assets/C_learn/Pasted_image_20250301213330.png)

## 变量是什么

```c
/*
全局变量
局部静态变量 被保存在特定区域

局部变量 是被保存在栈里的
*/
int g_a = 123;
/*执行该函数的时候会在栈里临时给变量分配空间，执行完后回收之前分配的空间*/
int add(volatile int v)
{
	volatile int a = 321;//在栈里
	v = v + a;
	return v;
}

int main()
{
	static volatile int s_a = 1;
	
	volatile int b = 456;
	
	volatile char name[100];
	
	name[0] = 'A';
	
	b = add(s_a);

	return 0;
}
```
![](./assets/C_learn/Pasted_image_20250301215443.png)

```bash
f103的内存基地址为0x20000000，结束地址0x20010000
```

## 栈 使用图
![](./assets/C_learn/Pasted_image_20250301221737.png)
```bash
跳转前先记录返回地址addrb，PC跳转去执行mymain地址
```
![](./assets/C_learn/Pasted_image_20250301222405.png)
```bash
push {r3,lr} 马上保存LR，因为即将调用C函数add,用R3来占坑，给b分配空间
在add中也是保存地址addrc，PC跳转去执行add的地址
为了避免覆盖addrb，将addrb保存到0x2000FFFC = 0x20010000 - 4
```

## 局部变量的初始化
![](./assets/C_learn/Pasted_image_20250301221918.png)
```bash
将0x1C8移入到寄存器R0
并将R0的值存入sp+0x00(0x2000FFF8)指向的地址中
```
### 加入char name后
![](./assets/C_learn/Pasted_image_20250301223742.png)
```bash
0x2000FF94 = 0x2000FFFC - 104
其中变量b的地址
sp + 0x64
= 0x2000FF94 + 0x64
= 0x2000FFF8
```

## 局部变量的释放
![](./assets/C_learn/Pasted_image_20250301225542.png)
```bash
PUSH lr,r0 分别指向0x2000FF90，0x2000FF8C
SUB 将sp指向0x2000FF88
给R0赋值321
将R0的值321保存到sp+0的地址下

读两个数据 
R0 = sp + 0 = a = 321
R1 = sp + 4 = v

R0 = R0 + R1 = 321 + v
将R0的值存到R1中，即实现v = v + a

POP回收(低标号寄存器对应低地址内存)
R2 <= 321
R3 <= R0
PC <= lr
这个过程sp向上移动回到0x2000FF94
```

## 全局变量和静态变量

![](./assets/C_learn/Pasted_image_20250302135026.png)
```bash
如果像局部变量一样初始化，浪费指令和flash空间

将初始化值放在flash的data段，并通过一个copy函数，一次性复制到内存中
```
![](./assets/C_learn/Pasted_image_20250302140812.png)
```bash
链接器给变量的分配指定了地址
```
![](./assets/C_learn/Pasted_image_20250302141047.png)
```bash
得到地址
读地址
写入变量b
```
### 对于超多初值为0或者无初值的变量
![](./assets/C_learn/Pasted_image_20250302142608.png)
![](./assets/C_learn/Pasted_image_20250302142528.png)
```bash
将变量从flash中复制到内存中，并使用一个赋值函数进行统一赋值
```

## 堆、栈

```bash
栈
默认向下增长
估计栈大小:寻找使用局部变量最多的调用链关系
选出空闲空间
堆
一块空闲内存，可以使用malloc/free来管理
char* str;
str = malloc(100);
strcpy(str,"hhhhh");
free(str);
```
![](./assets/C_learn/Pasted_image_20250302165602.png)
```
int b;
char name[100];

true:
push {lr}
sub sp,sp,#104

false:
push {r3,lr}
sub sp,sp,#100
下面写内存两次，上面写内存一次，更高效
```

## malloc函数实现

```c
volatile char mybuf[20*1024];
volatile int index = 0;
void *malloc(int size)
{
	char* ret = &mybuf[index];
	index += size;
	return ret;
}

int main()
{
	volatile int* p;
	p = 0x20001000;
	*p = 1234;
	
	p = malloc(100);
	p[0] = 0x12345678;
	
	return 0;
}
```
![](./assets/C_learn/Pasted_image_20250302200322.png)

## 函数
![](./assets/C_learn/Pasted_image_20250303115112.png)
```c
int add_val(int v)
{
	volatile int a = v;
	a++;
	return a;
}

void copy_add_val_to_ram(void)//将代码(上图机器码)复制到了内存当中执行
{
	unsigned char* src;
	unsigned int val = (unsigned int)add_val;
	unsigned char* dest = (unsigned char*)0x20008000;
	
	int i;
	src = (unsigned char*)(val & ~1);//地址最后一位为1，表示Thumb指令
	
	for(i = 0;i < 16;i++)
	{
		dest[i] = src[i];
	}
}
int main()
{
	volatile int a = 1;
	int (*f)(int v);
	
	a = add_val(a);
	
	copy_add_val_to_ram();

	f = (int (*)(int v))0x20008001;
	a = f(a);
	
	return 0;
}
```
```bash
对于copy_add_val_to_ram函数，将0x0800000c的十六字节复制到0x20008000

如要模拟调试，需要修改这部分(但依旧出现错误)主播暂未解决
否则出现error

调用函数:让CPU的PC寄存器等于"一系列机器码"的首地址，就是函数地址
```
![](./assets/C_learn/Pasted_image_20250303194054.png)
![](./assets/C_learn/Pasted_image_20250303200451.png)
![](./assets/C_learn/Pasted_image_20250303200724.png)

### 传递参数

![](./assets/C_learn/Pasted_image_20250303205650.png)
```bash
(实参)将参数的数值传递到R0寄存器，并没有影响到参数本身。传递实参就是传递实参的副本，如果想要修改参数本身，需要传递参数的地址
```

## 指针

```bash
指针变量，存放的是首地址
使用指针的本质，跟变量的访问做对比

char *p;
int *p;
struct dog *p;
int (*f)();
只记录首地址，对于32位系统都是4字节
```

```c
struct dog{
	int age;
	int sex;
};

int main()
{
	volatile int a = 1;
	int *p;
	struct dog wangcai = {1,1};
	struct dog clone;
	struct dog *pd;

	p = &a;//首地址
	*p = 2;//4字节
	
	pd = &clone;//首地址
	*pd = wangcai;//8字节

	return 0;
}
```
![](./assets/C_learn/Pasted_image_20250303211307.png)
![](./assets/C_learn/Pasted_image_20250303211513.png)

## 结构体

```c
int ages[10];
int sex[10];

struct student{
	int age;
	char sex; 
	int score;//addr是4字节对齐
};

volatile struct student students[10];

int main()
{
	students[0].age = 10;
	students[0].sex = 1;
	students[0].score = 100;

	return 0;
}

```

![](./assets/C_learn/Pasted_image_20250303224951.png)
```bash
对于结构体内部地址分配
```
![](./assets/C_learn/Pasted_image_20250303225941.png)

### 结构体字节对齐

```c
struct test {
    short age;     // 2 字节
    int sex;       // 4 字节
    char weight;   // 1 字节
    double height; // 8 字节
};

/*在 C 语言中，结构体的内存布局受到 **字节对齐（Alignment）** 规则的影响，
不同编译器或平台可能会有所不同。
假设在 **常见的 64 位 x86 或 ARM 平台**（默认使用最大字段的对齐方式）*/

```
![](./assets/C_learn/Pasted_image_20250327102819.png)
```c
如果想减少 **填充字节**，可以使用 `#pragma pack(n)` 让编译器调整对齐方式：

#pragma pack(1)  // 让所有成员按 1 字节对齐
struct test {
    short age;
    int sex;
    char weight;
    double height;
};
#pragma pack()  // 恢复默认对齐

这样结构体大小会变成 **15 字节**，但可能导致 CPU 访问效率下降。

优化字段顺序
struct test {
    double height;  // 8 字节对齐
    int sex;        // 4 字节对齐
    short age;      // 2 字节对齐
    char weight;    // 1 字节对齐
};

地址  |  字节
--------------------------
0-7   |  height (double)
8-11  |  sex (int)
12-13 |  age (short)
14    |  weight (char)
15    |  (填充 1 字节)
--------------------------
总大小 = 16 字节

在 C 语言结构体中，**填充（Padding）** 主要用于**确保每个成员都存储在符合对齐要求的地址**，以提高 CPU 访问效率。填充的原则遵循以下规则：
1. 每个成员的存储地址必须满足它的对齐要求
	- `char` **1 字节对齐**，可以存储在任何地址。
	- `short` **2 字节对齐**，必须存储在**2 的倍数地址**。
	- `int` **4 字节对齐**，必须存储在**4 的倍数地址**。
	- `double` **8 字节对齐**，必须存储在**8 的倍数地址**。
2. 成员间可能需要填充字节，以确保下一个成员正确对齐
	如果当前成员的大小不足以满足下一个成员的对齐要求，编译器会自动填充字节，以保证对齐。
3. 结构体的总大小必须是最大对齐要求的倍数
	结构体的**总大小** 需要**是对齐要求最高的成员的整数倍**，可能会在结构体末尾填充额外字节。
```

![](./assets/C_learn/Pasted_image_20250327103020.png)

## 联合体

```c
struct student{
	int age;
	union{
		int kg;
		int liang;
	}weight;
};

int main()
{
	volatile struct dog wangcai;
	wangcai.age = 1;
	wangcai.weight.kg = 1;
	wangcai.weight.liang = 30;

	return 0;
}
```
![](./assets/C_learn/Pasted_image_20250305161646.png)
![](./assets/C_learn/Pasted_image_20250305161735.png)
![](./assets/C_learn/Pasted_image_20250305161810.png)
```bash
修改联合体内部变量数据类型，可以看到联合体内部变量首地址相同，但大小不同
```

## 位域

```c
struct cat{
	int sex:1;
	int old:1;
	int age;
};

int main()
{
	volatile struct cat abc;
	abc.sex = 1;
	abc.old = 0;
	abc.age = 1;

	return 0;
}

struct test{
	short age;
	int sex;
	char weight;
	double height;
};
```
![](./assets/C_learn/Pasted_image_20250305162713.png)
```bash
先读取sp指向的地址存的值，清除第一位,加一,再写回去
再读取sp指向的地址存的值，清除第二位，再写回去
```